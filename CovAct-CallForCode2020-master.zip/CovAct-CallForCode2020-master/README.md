# CovAct-CallForCode2020
This repository is for the project CovAct built for CallForCode 2020.
